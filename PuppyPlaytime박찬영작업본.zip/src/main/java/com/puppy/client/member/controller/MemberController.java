package com.puppy.client.member.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MemberController {
	/*
	@RequestMapping(value="/client/login", method=RequestMethod.GET)
	public String login() {
		return "client/login/login";
	}*/
}
